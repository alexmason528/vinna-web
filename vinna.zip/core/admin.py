from django.contrib import admin

from core.models import Language, Country, State

admin.site.register(Language)
admin.site.register(Country)
admin.site.register(State)

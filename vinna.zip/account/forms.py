from django import forms
from django.contrib.auth.models import User
from django.utils.translation import ugettext as _
from .models import Account
#from .models import Post

class UserForm(forms.ModelForm):

    email = forms.EmailField(required=True, widget=forms.TextInput(attrs={'placeholder': _('Email')}))

    class Meta:
        model = User
        fields = ('username', 'email', 'password',)

    def save(self, commit=True):
            user = super(MyRegistrationForm, self).save(commit=False)
            user.email = self.cleaned_data['email']
            # user.set_password(self.cleaned_data['password1'])

            if commit:
                user.save()

            return user


class AccountForm(forms.ModelForm):
    first_name = forms.CharField(label='first_name', required=True, widget=forms.TextInput(attrs={'placeholder': _('First Name')}))
    last_name = forms.CharField(label='last_name', required=True, widget=forms.TextInput(attrs={'placeholder': _('Last Name')}))
    dob_month = forms.IntegerField(label='Month', required=True, widget=forms.NumberInput(attrs={'placeholder': _('Month')}))
    dob_day = forms.IntegerField(label='Day', required=True, widget=forms.NumberInput(attrs={'placeholder': _('Day')}))
    dob_year = forms.IntegerField(label='Year', required=True, widget=forms.NumberInput(attrs={'placeholder': _('Year')}))

    class Meta:
        model = Account
        fields = ('language', 'first_name', 'last_name', 'dob')

    def is_valid(self):
        # run the parent validation first
        valid = super(AccountForm, self).is_valid()

        # we're done now if not valid
        if not valid:
            return valid

        if dob_month < 1 and dob_month > 12:
            self._errors['dob_month'] = _('Month is invalid')

        if dob_day < 1 and dob_day > 31:
            self._errors['invalid_dob_day'] = _('Day is invalid')

        if dob_year < 1900 and dob_year > 2015:
            self._errors['invalid_dob_year'] = _('Year is invalid')

        try:
            AccountForm.dob = datetime(dob_year, dob_month, dob_day)
        except (ValueError, TypeError):
            self._errors['invalid_dob'] = _('DOB is invalid')

        if self._errors|length > 0:
            return False

        return True


    def save(self, commit=True):
            user = super(MyRegistrationForm, self).save(commit=False)
            user.email = self.cleaned_data['email']
            # user.set_password(self.cleaned_data['password1'])

            if commit:
                user.save()

            return user

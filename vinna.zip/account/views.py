from django.utils.translation import ugettext as _
from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime

from django.contrib.auth.forms import UserCreationForm
from .forms import UserForm
from .forms import AccountForm

from core.models import Language

# Create your views here.
def index(request):
    return HttpResponse("Hello, world. You're at the account index.")

def register(request):
    if request.method == "POST":
#        print(request.POST)
        form_user = UserForm(request.POST)
        form_account = AccountForm(request.POST)

        if form_user.is_valid() and form_account.is_valid():
            print('valid')

            new_user = User.objects.create_user(**form.cleaned_data)
            login(new_user)

            # redirect, or however you want to get to the main view
            return HttpResponseRedirect('/account/register/step2/')
    else:
        form_user = UserForm()
        form_account = AccountForm()

    context = { 'languages' : Language.objects.all().order_by('text'), 'form_account' : form_account }

    return render(request, 'account/register.html', context)

def register_step_2(request):
    return HttpResponse("Step 2")

def login(request):
    context = { 'languages' : Language.objects.all().order_by('text') }
    return HttpRedirect("/");

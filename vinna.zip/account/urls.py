from django.conf.urls import url

from . import views

app_name = 'account'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^register/$', views.register, name='register'),
#    url(r'^register/step2/$', views.register_step_2, name='register_step_2'),
    url(r'^login/$', views.login, name='login'),
]

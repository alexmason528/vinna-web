from django.apps import AppConfig


class OpenConfig(AppConfig):
    name = 'open'
